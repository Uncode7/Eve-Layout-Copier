
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EVE Layout Copier v3.3
- Full language refresh on change
- Donate button and completion message translated
- English default
"""

import os, re, shutil, threading, webbrowser
from datetime import datetime
from tkinter import *
from tkinter import filedialog
import sys
import os


APP_NAME = "EVE Layout Copier v3.3"
BACKUP_DIRNAME = "backup folder"
DONATION_URL = "https://zkillboard.com/character/2116662655"
TARGET_PATTERNS = [r"^core_char_\d+\.dat$", r"^core_user_\d+\.dat$"]

LANG_TEXTS = {
    "English": {
        "origin": "Origin (select 1 char + 1 user):",
        "dest": "Destination (select 1+ char + 1+ user):",
        "choose_origin": "Choose origin folder...",
        "choose_dest": "Choose destination folder...",
        "mark_all": "Mark/Unmark All",
        "dry_run": "Dry-run (test mode)",
        "backup": "Backup before (recommended)",
        "execute": "Execute copy",
        "donate": 'If you liked it, send a donation to "Plunder Skol" in ISK! 💙 s2',
        "done": "Copy completed successfully!",
    },
    "Português": {
        "origin": "Origem (selecione 1 char + 1 user):",
        "dest": "Destino (selecione 1+ char + 1+ user):",
        "choose_origin": "Escolher pasta de origem...",
        "choose_dest": "Escolher pasta de destino...",
        "mark_all": "Marcar/Tirar Tudo",
        "dry_run": "Dry-run (modo de teste)",
        "backup": "Fazer backup antes (recomendado)",
        "execute": "Executar cópia",
        "donate": 'Se você gostou, faça uma doação para "Plunder Skol" em ISK! 💙 s2',
        "done": "Cópia concluída com sucesso!",
    },
    "中文": {
        "origin": "来源 (选择1个char和1个user):",
        "dest": "目标 (选择1个或多个char和user):",
        "choose_origin": "选择来源文件夹...",
        "choose_dest": "选择目标文件夹...",
        "mark_all": "全选/取消",
        "dry_run": "Dry-run（测试模式）",
        "backup": "操作前备份（推荐）",
        "execute": "执行复制",
        "donate": '如果喜欢，请向 "Plunder Skol" 捐赠 ISK！💙 s2',
        "done": "复制完成！",
    },
    "Русский": {
        "origin": "Источник (выберите 1 char и 1 user):",
        "dest": "Назначение (выберите 1+ char и 1+ user):",
        "choose_origin": "Выбрать папку источника...",
        "choose_dest": "Выбрать папку назначения...",
        "mark_all": "Выбрать/Снять все",
        "dry_run": "Dry-run (тестовый режим)",
        "backup": "Резервное копирование перед (рекомендуется)",
        "execute": "Выполнить копирование",
        "donate": 'Если вам понравилось, отправьте пожертвование персонажу "Plunder Skol" в ISK! 💙 s2',
        "done": "Копирование завершено успешно!",
    },
    "Français": {
        "origin": "Origine (sélectionner 1 char + 1 user):",
        "dest": "Destination (sélectionner 1+ char + 1+ user):",
        "choose_origin": "Choisir le dossier d'origine...",
        "choose_dest": "Choisir le dossier de destination...",
        "mark_all": "Tout marquer/démarquer",
        "dry_run": "Dry-run (mode test)",
        "backup": "Sauvegarder avant (recommandé)",
        "execute": "Exécuter la copie",
        "donate": 'Si vous avez aimé, faites un don à "Plunder Skol" en ISK ! 💙 s2',
        "done": "Copie terminée avec succès !",
    }
}

def is_target(f): return any(re.match(p, f) for p in TARGET_PATTERNS)
def find_tranquility_path():
    local = os.getenv("LOCALAPPDATA")
    if not local: return None
    base = os.path.join(local, "CCP", "EVE")
    if not os.path.exists(base): return None
    for e in os.listdir(base):
        low = e.lower()
        if "tranquility" in low and "sisi" not in low:
            path = os.path.join(base, e, "settings_Default")
            if os.path.isdir(path): return path
    return None
def backup_files(paths):
    folder = os.path.join(os.getcwd(), BACKUP_DIRNAME, datetime.now().strftime("%Y-%m-%d_%H-%M-%S"))
    os.makedirs(folder, exist_ok=True)
    for f in paths:
        try: shutil.copy2(f, os.path.join(folder, os.path.basename(f)))
        except: pass
    return folder

class EveLayoutCopier:
    def __init__(self, root):
        self.root = root
        self.origin_path = find_tranquility_path()
        self.dest_path = find_tranquility_path()
        self.origin_files, self.dest_files = [], []
        self.origin_checks, self.dest_checks = {}, {}
        self.dry_run = BooleanVar(value=False)
        self.backup = BooleanVar(value=True)
        self.lang = StringVar(value="English")
        self.build_ui()
        self.refresh_lists()

    def build_ui(self):
        self.root.title(APP_NAME)
        self.root.geometry("900x600")
        top = Frame(self.root); top.pack(fill=X, pady=5)
        Label(top, text="Language:").pack(side=LEFT, padx=5)
        OptionMenu(top, self.lang, *LANG_TEXTS.keys(), command=self.update_language).pack(side=LEFT)

        main = Frame(self.root); main.pack(fill=BOTH, expand=True, padx=6, pady=6)
        self.origin_frame = LabelFrame(main, text=self.t("origin"))
        self.origin_frame.pack(side=LEFT, fill=BOTH, expand=True, padx=4)
        self.btn_origin = Button(self.origin_frame, text=self.t("choose_origin"), command=self.pick_origin)
        self.btn_origin.pack(pady=2)
        self.origin_canvas = Canvas(self.origin_frame, highlightthickness=0)
        self.origin_scroll = Scrollbar(self.origin_frame, orient=VERTICAL, command=self.origin_canvas.yview, width=18)
        self.origin_box = Frame(self.origin_canvas)
        self.origin_box.bind("<Configure>", lambda e: self.origin_canvas.configure(scrollregion=self.origin_canvas.bbox("all")))
        self.origin_canvas.create_window((0, 0), window=self.origin_box, anchor="nw")
        self.origin_canvas.configure(yscrollcommand=self.origin_scroll.set)
        self.origin_canvas.pack(side=LEFT, fill=BOTH, expand=True)
        self.origin_scroll.pack(side=RIGHT, fill=Y)

        self.dest_frame = LabelFrame(main, text=self.t("dest"))
        self.dest_frame.pack(side=LEFT, fill=BOTH, expand=True, padx=4)
        self.btn_dest = Button(self.dest_frame, text=self.t("choose_dest"), command=self.pick_dest)
        self.btn_dest.pack(pady=2)
        self.btn_mark = Button(self.dest_frame, text=self.t("mark_all"), command=self.toggle_all_dest)
        self.btn_mark.pack(pady=2)
        self.dest_canvas = Canvas(self.dest_frame, highlightthickness=0)
        self.dest_scroll = Scrollbar(self.dest_frame, orient=VERTICAL, command=self.dest_canvas.yview, width=18)
        self.dest_box = Frame(self.dest_canvas)
        self.dest_box.bind("<Configure>", lambda e: self.dest_canvas.configure(scrollregion=self.dest_canvas.bbox("all")))
        self.dest_canvas.create_window((0, 0), window=self.dest_box, anchor="nw")
        self.dest_canvas.configure(yscrollcommand=self.dest_scroll.set)
        self.dest_canvas.pack(side=LEFT, fill=BOTH, expand=True)
        self.dest_scroll.pack(side=RIGHT, fill=Y)

        opts = Frame(self.root); opts.pack(fill=X, pady=6)
        self.cb_dry = Checkbutton(opts, text=self.t("dry_run"), variable=self.dry_run)
        self.cb_dry.pack(side=LEFT, padx=4)
        self.cb_backup = Checkbutton(opts, text=self.t("backup"), variable=self.backup)
        self.cb_backup.pack(side=LEFT, padx=4)
        self.btn_exec = Button(opts, text=self.t("execute"), state=DISABLED, command=self.execute_copy)
        self.btn_exec.pack(side=LEFT, padx=8)
        self.link_btn = Button(opts, text=self.t("donate"), command=lambda: webbrowser.open(DONATION_URL), fg="blue", cursor="hand2")
        self.link_btn.pack(side=LEFT, padx=12)

    def t(self, key): return LANG_TEXTS[self.lang.get()][key]

    def update_language(self, *_):
        self.origin_frame.config(text=self.t("origin"))
        self.dest_frame.config(text=self.t("dest"))
        self.btn_origin.config(text=self.t("choose_origin"))
        self.btn_dest.config(text=self.t("choose_dest"))
        self.btn_mark.config(text=self.t("mark_all"))
        self.cb_dry.config(text=self.t("dry_run"))
        self.cb_backup.config(text=self.t("backup"))
        self.btn_exec.config(text=self.t("execute"))
        self.link_btn.config(text=self.t("donate"))

    def refresh_lists(self):
        for w in self.origin_box.winfo_children(): w.destroy()
        for w in self.dest_box.winfo_children(): w.destroy()
        if self.origin_path and os.path.isdir(self.origin_path):
            self.origin_files = [os.path.join(self.origin_path, f) for f in os.listdir(self.origin_path) if is_target(f)]
        else: self.origin_files = []
        if self.dest_path and os.path.isdir(self.dest_path):
            self.dest_files = [os.path.join(self.dest_path, f) for f in os.listdir(self.dest_path) if is_target(f)]
        else: self.dest_files = []
        self.origin_checks.clear(); self.dest_checks.clear()
        for f in self.origin_files:
            var = BooleanVar(value=False)
            cb = Checkbutton(self.origin_box, text=os.path.basename(f), variable=var, command=self.validate_selection)
            cb.pack(anchor=W)
            self.origin_checks[f] = var
        for f in self.dest_files:
            var = BooleanVar(value=False)
            cb = Checkbutton(self.dest_box, text=os.path.basename(f), variable=var, command=self.validate_selection)
            cb.pack(anchor=W)
            self.dest_checks[f] = var
        self.validate_selection()

    def pick_origin(self):
        path = filedialog.askdirectory(title=self.t("choose_origin"))
        if path: self.origin_path = path; self.refresh_lists()
    def pick_dest(self):
        path = filedialog.askdirectory(title=self.t("choose_dest"))
        if path: self.dest_path = path; self.refresh_lists()

    def toggle_all_dest(self):
        state = not all(v.get() for v in self.dest_checks.values())
        for v in self.dest_checks.values(): v.set(state)
        self.validate_selection()

    def validate_selection(self):
        def type_of(p): return "char" if "core_char_" in os.path.basename(p) else "user"
        origin_selected = {"char": [], "user": []}
        dest_selected = {"char": [], "user": []}
        for p, v in self.origin_checks.items():
            if v.get(): origin_selected[type_of(p)].append(p)
        for p, v in self.dest_checks.items():
            if v.get(): dest_selected[type_of(p)].append(p)
        for tp in ["char", "user"]:
            if len(origin_selected[tp]) > 1:
                last = origin_selected[tp][-1]
                for p, v in self.origin_checks.items():
                    if type_of(p) == tp: v.set(p == last)
                origin_selected[tp] = [last]
        valid = (len(origin_selected["char"]) == 1 and len(origin_selected["user"]) == 1 and
                 len(dest_selected["char"]) >= 1 and len(dest_selected["user"]) >= 1)
        self.btn_exec.config(state=NORMAL if valid else DISABLED)

    def execute_copy(self):
        threading.Thread(target=self.do_copy, daemon=True).start()
    def do_copy(self):
        origin = {"char": None, "user": None}; dest = {"char": [], "user": []}
        for p, v in self.origin_checks.items():
            if v.get():
                if "core_char_" in os.path.basename(p): origin["char"] = p
                else: origin["user"] = p
        for p, v in self.dest_checks.items():
            if v.get():
                if "core_char_" in os.path.basename(p): dest["char"].append(p)
                else: dest["user"].append(p)
        if self.backup.get(): backup_files(dest["char"] + dest["user"])
        char_data = open(origin["char"], "rb").read() if origin["char"] else None
        user_data = open(origin["user"], "rb").read() if origin["user"] else None
        if not self.dry_run.get():
            if char_data:
                for f in dest["char"]:
                    with open(f, "wb") as o: o.write(char_data)
            if user_data:
                for f in dest["user"]:
                    with open(f, "wb") as o: o.write(user_data)
        self.show_done_message()

    def show_done_message(self):
        popup = Toplevel(self.root)
        popup.title(APP_NAME)
        Label(popup, text=self.t("done"), wraplength=400, justify=LEFT).pack(padx=10, pady=10)
        Button(popup, text="Ok 7o", command=popup.destroy).pack(pady=5)


if __name__ == "__main__":
    root = Tk()

    # --- configuração do ícone da janela ---
    if getattr(sys, 'frozen', False):
        base_path = sys._MEIPASS
    else:
        base_path = os.path.abspath(".")

    icon_path = os.path.join(base_path, "icon.ico")
    try:
        root.iconbitmap(icon_path)
    except Exception as e:
        print("Warning: could not set icon:", e)
    # ---------------------------------------

    EveLayoutCopier(root)
    root.mainloop()

